var reader_filters =
[
    [ "SourceRemoteMVX2FileSyncReader", "_source_remote_m_v_x2_file_sync_reader.html", null ],
    [ "SourceRemoteMVX2FileAsyncRealtimeReader", "_source_remote_m_v_x2_file_async_realtime_reader.html", null ],
    [ "SourceRemoteMVX2FileMutateAsyncReaderBackend", "_source_remote_m_v_x2_file_mutate_async_reader_backend.html", null ],
    [ "MutateRemoteMVX2FileAsyncReader", "_mutate_remote_m_v_x2_file_async_reader.html", null ]
];