var draco_notes =
[
    [ "Apache v2 license", "apache_v2_license.html", null ]
];