var searchData=
[
  ['bsd_20license_13',['BSD license',['../bsd_license.html',1,'nanoflann_notes']]]
];
