var class_m_v_common_1_1_android_system_logger_sink =
[
    [ "AndroidSystemLoggerSink", "class_m_v_common_1_1_android_system_logger_sink.html#a6ee8752e4e5a8eaf0e385d11c40530e8", null ],
    [ "~AndroidSystemLoggerSink", "class_m_v_common_1_1_android_system_logger_sink.html#a01f87d446cca7a73fbcdad5e1c569251", null ],
    [ "HandleLogEntry", "class_m_v_common_1_1_android_system_logger_sink.html#a7e35ba537a354d0d25c03a3292e5472c", null ]
];