var searchData=
[
  ['weakloggerptr_316',['WeakLoggerPtr',['../class_m_v_common_1_1_weak_logger_ptr.html',1,'MVCommon']]]
];
