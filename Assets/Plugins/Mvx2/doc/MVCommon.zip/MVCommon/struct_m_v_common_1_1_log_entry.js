var struct_m_v_common_1_1_log_entry =
[
    [ "ThreadID", "struct_m_v_common_1_1_log_entry.html#abf232fa4d99b6389bdd867aff8093235", null ],
    [ "Timestamp", "struct_m_v_common_1_1_log_entry.html#a8e389627f1c9fc0c080bd9565801c7d1", null ],
    [ "LogEntry", "struct_m_v_common_1_1_log_entry.html#a9338db9e73c6087287624cd00356cd2a", null ],
    [ "GetLevel", "struct_m_v_common_1_1_log_entry.html#a8e6e3145fcbc2afaa2af2b999fe23327", null ],
    [ "GetMessage", "struct_m_v_common_1_1_log_entry.html#a70d14a36c013263662946a46bdcf6c7c", null ],
    [ "GetTag", "struct_m_v_common_1_1_log_entry.html#ac4687c94512aaee7111f91101cb8d7b7", null ],
    [ "GetThreadID", "struct_m_v_common_1_1_log_entry.html#a5221fad42031a610b87c70bc774ed4eb", null ],
    [ "GetTimestamp", "struct_m_v_common_1_1_log_entry.html#ae837da2854ee30ca66e2f208fbb01fa6", null ]
];