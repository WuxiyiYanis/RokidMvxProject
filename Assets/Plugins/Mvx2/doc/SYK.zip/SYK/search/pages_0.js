var searchData=
[
  ['data_20layer_20types_6',['Data layer types',['../data_layers.html',1,'']]],
  ['datatypesyk_7',['DataTypeSYK',['../_data_type_s_y_k.html',1,'data_layers']]],
  ['decompressor_20filters_8',['Decompressor filters',['../decompressors.html',1,'']]]
];
