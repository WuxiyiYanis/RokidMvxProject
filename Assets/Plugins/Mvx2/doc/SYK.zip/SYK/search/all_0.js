var searchData=
[
  ['data_20layer_20types_0',['Data layer types',['../data_layers.html',1,'']]],
  ['datatypesyk_1',['DataTypeSYK',['../_data_type_s_y_k.html',1,'data_layers']]],
  ['decompressor_20filters_2',['Decompressor filters',['../decompressors.html',1,'']]]
];
