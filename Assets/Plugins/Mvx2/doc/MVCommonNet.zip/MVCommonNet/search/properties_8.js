var searchData=
[
  ['major_395',['major',['../class_m_v_common_1_1_version_info.html#a33685ed85e079d276afaf4979874ece9',1,'MVCommon::VersionInfo']]],
  ['message_396',['Message',['../class_m_v_common_1_1_log_entry.html#ac8b968e56ed0733e1a7e64724100a0a9',1,'MVCommon::LogEntry']]],
  ['minor_397',['minor',['../class_m_v_common_1_1_version_info.html#ad101ca6ceecb91a3a7436a0b9a64fc97',1,'MVCommon::VersionInfo']]]
];
