var class_m_v_common_1_1_logger_registry =
[
    [ "ClearRegistry", "class_m_v_common_1_1_logger_registry.html#a95823a1fc087842df0d29352fcdb2260", null ],
    [ "GetLogger", "class_m_v_common_1_1_logger_registry.html#a1451771f4dd6e616f2a4bdea44fa7199", null ],
    [ "RegisterLogger", "class_m_v_common_1_1_logger_registry.html#a1c52abc25e4cad80b1f359f83a915329", null ],
    [ "UnregisterLogger", "class_m_v_common_1_1_logger_registry.html#ab639546d45a59b6f6bfe3aa0a8a33d84", null ]
];