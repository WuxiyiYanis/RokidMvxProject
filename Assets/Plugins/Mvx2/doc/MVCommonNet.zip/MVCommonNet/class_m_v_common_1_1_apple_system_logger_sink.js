var class_m_v_common_1_1_apple_system_logger_sink =
[
    [ "AppleSystemLoggerSink", "class_m_v_common_1_1_apple_system_logger_sink.html#a19f7f59554d64dfc656d8501f7ae49f2", null ]
];