var class_m_v_common_1_1_version_info =
[
    [ "VersionInfo", "class_m_v_common_1_1_version_info.html#aebab81337323b561bfa3ae6111ed980d", null ],
    [ "VersionInfo", "class_m_v_common_1_1_version_info.html#adf01dda721efab7c1ae554feca2bce4c", null ],
    [ "VersionInfo", "class_m_v_common_1_1_version_info.html#ae9ef913e6f07e187a8b0f3b7baeb2d87", null ],
    [ "DestroyNativeObject", "class_m_v_common_1_1_version_info.html#ad358d75dc737a438f1591a36b088b5bf", null ],
    [ "ToCommonString", "class_m_v_common_1_1_version_info.html#a5678193abc045d65d3e5754fc09716a6", null ],
    [ "major", "class_m_v_common_1_1_version_info.html#a33685ed85e079d276afaf4979874ece9", null ],
    [ "minor", "class_m_v_common_1_1_version_info.html#ad101ca6ceecb91a3a7436a0b9a64fc97", null ],
    [ "patch", "class_m_v_common_1_1_version_info.html#a51296a0b2e4f77a64991103cd3380a6a", null ]
];