var _m_v_z_m_q_network_version_8h =
[
    [ "MVZMQNETWORK_VERSION_MAJOR", "_m_v_z_m_q_network_version_8h.html#a9ffbe570b79c4dfdf087b3a80e714424", null ],
    [ "MVZMQNETWORK_VERSION_MINOR", "_m_v_z_m_q_network_version_8h.html#afdcb031d084a2de7aeaa79b9866e741d", null ],
    [ "MVZMQNETWORK_VERSION_PATCH", "_m_v_z_m_q_network_version_8h.html#a6e8f6f11848992ca5a764398902f4e10", null ],
    [ "MVX_VERSION", "_m_v_z_m_q_network_version_8h.html#a49deb850b0961b8d0027489c8091707b", null ],
    [ "MVZMQNETWORK_VERSION", "_m_v_z_m_q_network_version_8h.html#a2420a0f8286a2ec9e63a8b0bb71b6dd7", null ]
];