var searchData=
[
  ['current_5fprotocol_5fversion_0',['CURRENT_PROTOCOL_VERSION',['../_protocol_8h.html#ad962153a88c418d80a991e01d0a91376',1,'Protocol.h']]]
];
