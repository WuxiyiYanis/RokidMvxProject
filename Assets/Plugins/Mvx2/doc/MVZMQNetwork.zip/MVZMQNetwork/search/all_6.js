var searchData=
[
  ['transmitter_34',['Transmitter',['../class_m_v_z_m_q_network_1_1_transmitter.html',1,'MVZMQNetwork::Transmitter'],['../class_m_v_z_m_q_network_1_1_transmitter.html#a1a6b757c385a41dd5c4147772225a2a1',1,'MVZMQNetwork::Transmitter::Transmitter()']]]
];
