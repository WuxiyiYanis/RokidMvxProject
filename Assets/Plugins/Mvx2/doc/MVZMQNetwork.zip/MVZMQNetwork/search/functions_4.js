var searchData=
[
  ['_7ereceiver_54',['~Receiver',['../class_m_v_z_m_q_network_1_1_receiver.html#ac7ab27f13acee069d04470d93515a413',1,'MVZMQNetwork::Receiver']]],
  ['_7etransmitter_55',['~Transmitter',['../class_m_v_z_m_q_network_1_1_transmitter.html#a46516c4e2ccc1312086de2617cfa6286',1,'MVZMQNetwork::Transmitter']]]
];
