var searchData=
[
  ['receiveatom_26',['ReceiveAtom',['../class_m_v_z_m_q_network_1_1_receiver.html#a8162faf923351925aa0a4978b9f28176',1,'MVZMQNetwork::Receiver']]],
  ['receiver_27',['Receiver',['../class_m_v_z_m_q_network_1_1_receiver.html',1,'MVZMQNetwork::Receiver'],['../class_m_v_z_m_q_network_1_1_receiver.html#aca118fe93a1c90c2fbce0ccaea30766a',1,'MVZMQNetwork::Receiver::Receiver()']]],
  ['release_20notes_28',['Release Notes',['../release_notes.html',1,'']]],
  ['resetdroppedatomscounter_29',['ResetDroppedAtomsCounter',['../class_m_v_z_m_q_network_1_1_transmitter.html#a2d66b4be5251f0a544f78e09fab60c01',1,'MVZMQNetwork::Transmitter']]],
  ['running_30',['Running',['../class_m_v_z_m_q_network_1_1_receiver.html#a7a984a39d6d807cdca77dd4c918e0645',1,'MVZMQNetwork::Receiver::Running()'],['../class_m_v_z_m_q_network_1_1_transmitter.html#a4a06ffada0e56a8d981aaf251438a8fa',1,'MVZMQNetwork::Transmitter::Running()']]]
];
