var searchData=
[
  ['canrenderthumbnail_0',['CanRenderThumbnail',['../class_mvx2_basic_i_o_1_1_mvx2_file_basic_data_info.html#a24aa726a2f256a08ef8548bd1c0bc9e1',1,'Mvx2BasicIO::Mvx2FileBasicDataInfo']]],
  ['createandrenderthumbnail_1',['CreateAndRenderThumbnail',['../class_mvx2_basic_i_o_1_1_mvx2_file_basic_data_info.html#aca29ac651f127840f6c3bb9a061a5457',1,'Mvx2BasicIO::Mvx2FileBasicDataInfo']]]
];
