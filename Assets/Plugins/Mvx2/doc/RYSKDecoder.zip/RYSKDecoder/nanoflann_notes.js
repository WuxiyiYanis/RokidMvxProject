var nanoflann_notes =
[
    [ "BSD license", "bsd_license.html", null ]
];