var _plugins_loader_8h =
[
    [ "LoadPlugin", "_plugins_loader_8h.html#acd7f936b9dbf6eb176f97eb68e68bba5", null ],
    [ "LoadPluginsInFolder", "_plugins_loader_8h.html#a3439c97acfe4de2b326aaf191b923a1e", null ]
];