var class_mvx2_a_p_i_1_1_data_profile =
[
    [ "DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html#a8e191579d66b3920261d99f944195749", null ],
    [ "DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html#abce957aead34a5c58df7d3b3003628fd", null ],
    [ "DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html#ae90143989eaf87714a93fdcdae614744", null ],
    [ "~DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html#a69f463f3d9419f6d0baaac696959d399", null ],
    [ "GetCompressedTypeGuid", "class_mvx2_a_p_i_1_1_data_profile.html#ab5d8943e627d64ea9a2f3bf765ded514", null ],
    [ "GetPurposeGuid", "class_mvx2_a_p_i_1_1_data_profile.html#a9aa0aba0c2b2a9b9d397ab93f5618ad5", null ],
    [ "GetTypeGuid", "class_mvx2_a_p_i_1_1_data_profile.html#a6323f43ad21cec811bb61aec89a148f4", null ]
];