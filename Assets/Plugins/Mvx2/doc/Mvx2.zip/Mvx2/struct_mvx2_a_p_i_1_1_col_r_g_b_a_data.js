var struct_mvx2_a_p_i_1_1_col_r_g_b_a_data =
[
    [ "a", "struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#ad7b99e1fde2ab41be124d9f4c7285f0f", null ],
    [ "b", "struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#a6608b7c809c631a19d558404e7e50d20", null ],
    [ "g", "struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#a7e55dc9eedad2016a2ff729ec89bbfe6", null ],
    [ "r", "struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#a5a9324cfd8bbdf9997eeb20e4307b026", null ]
];