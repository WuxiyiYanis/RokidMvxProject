var class_mvx2_a_p_i_1_1_frame =
[
    [ "Iterator", "class_mvx2_a_p_i_1_1_frame.html#a524a3d220305e81d477ec1126f1c09a3", null ],
    [ "Frame", "class_mvx2_a_p_i_1_1_frame.html#a65c0519c58f22f9e73f2008c928585fb", null ],
    [ "~Frame", "class_mvx2_a_p_i_1_1_frame.html#a02d81ce7c74c83cd5205cf845b8e2f0a", null ],
    [ "ActivateStreamWithIndex", "class_mvx2_a_p_i_1_1_frame.html#a02d0038a5f009cf1209d0e8db094f2dc", null ],
    [ "DataProfilesBegin", "class_mvx2_a_p_i_1_1_frame.html#af60c953cac66925e48e7368e00a9c4da", null ],
    [ "DataProfilesEnd", "class_mvx2_a_p_i_1_1_frame.html#a96d37f5e3a486d7364a0a0b8cd4a2ebb", null ],
    [ "GetActiveStream", "class_mvx2_a_p_i_1_1_frame.html#aa6fcb949ecbc835a6a79d0f3350a8292", null ],
    [ "GetActiveStreamIndex", "class_mvx2_a_p_i_1_1_frame.html#a4108d79bbf995abb0b4712afd7516ca4", null ],
    [ "GetNumStreams", "class_mvx2_a_p_i_1_1_frame.html#a82e1d90b5877377e3c28840020cee49b", null ],
    [ "GetStreamAtomNr", "class_mvx2_a_p_i_1_1_frame.html#a2c22098efb2b5c0155b8ccb38013e6b2", null ],
    [ "GetStreamAtomTimestamp", "class_mvx2_a_p_i_1_1_frame.html#a8661e2eef3a627433d50da82479acb45", null ],
    [ "GetStreamId", "class_mvx2_a_p_i_1_1_frame.html#a65339eb8aac1ea42f6b872e81116478d", null ],
    [ "GetStreams", "class_mvx2_a_p_i_1_1_frame.html#a9efa71db11942d137f1e5167b353f975", null ],
    [ "StreamContainsDataLayer", "class_mvx2_a_p_i_1_1_frame.html#a36300f4c48502eafee14b7defc3a1a36", null ]
];