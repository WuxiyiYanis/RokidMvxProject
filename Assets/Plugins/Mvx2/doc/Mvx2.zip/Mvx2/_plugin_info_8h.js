var _plugin_info_8h =
[
    [ "PluginInfo", "struct_m_v_x_1_1_plugin_info.html", "struct_m_v_x_1_1_plugin_info" ],
    [ "MVX_PLUGIN", "_plugin_info_8h.html#a66467fa1f3aaa47ad5e899d2b8d7c0e5", null ],
    [ "MVX_PLUGIN_API", "_plugin_info_8h.html#a742bc0529bb9b2b6714f5a45058f28c6", null ],
    [ "MVX_PLUGIN_INFO_OBJECT_NAME", "_plugin_info_8h.html#af797a566ccfdda3e7c9e7429396beb3e", null ],
    [ "MVX_PLUGIN_INFO_OBJECT_NAME_STR", "_plugin_info_8h.html#a43f51443c26174a5a491771b2378531c", null ]
];