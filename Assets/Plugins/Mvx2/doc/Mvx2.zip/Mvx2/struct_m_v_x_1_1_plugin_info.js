var struct_m_v_x_1_1_plugin_info =
[
    [ "mvxVersion", "struct_m_v_x_1_1_plugin_info.html#af79425b124e2000fefde5de85ec6a7b0", null ],
    [ "mvxVersionStr", "struct_m_v_x_1_1_plugin_info.html#a5fa440ef7f6395848534fadc8fbec407", null ],
    [ "pluginName", "struct_m_v_x_1_1_plugin_info.html#ab93116de0279d4937b69ba609db61b37", null ],
    [ "pluginVersion", "struct_m_v_x_1_1_plugin_info.html#a0ce1076a5a5534e02423efdb2ba6613c", null ]
];