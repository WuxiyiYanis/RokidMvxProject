var class_mvx2_a_p_i_1_1_frame_listener =
[
    [ "~FrameListener", "class_mvx2_a_p_i_1_1_frame_listener.html#a69befa850a01a11b198548307f7fe192", null ],
    [ "OnFrameProcessed", "class_mvx2_a_p_i_1_1_frame_listener.html#a8c15b0ede178fcb4a8b4efc5e2c639ac", null ]
];