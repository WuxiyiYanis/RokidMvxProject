var _plugin_database_8h =
[
    [ "AddPlugin", "_plugin_database_8h.html#acecda515fbb0345db0a43e05787eb755", null ],
    [ "LoadPluginsFromCacheFile", "_plugin_database_8h.html#a24c3bb342273c26e1b2cb91d64e438e2", null ],
    [ "SavePluginsToCacheFile", "_plugin_database_8h.html#a2d57634b5592762e5dc0f8c3859cec1e", null ],
    [ "ScanFolderForPlugins", "_plugin_database_8h.html#a57071d42f38b1d371aaf32c61100f7b6", null ]
];