var hierarchy =
[
    [ "Mvx2API::AtomList", "class_mvx2_a_p_i_1_1_atom_list.html", null ],
    [ "Mvx2API::ColRGBAData", "struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html", null ],
    [ "MVX::DataLayerClassInfo", "class_m_v_x_1_1_data_layer_class_info.html", null ],
    [ "MVX::DataLayerFactoryIterator", "class_m_v_x_1_1_data_layer_factory_iterator.html", null ],
    [ "Mvx2API::DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html", null ],
    [ "Mvx2API::DataProfileHasher", "struct_mvx2_a_p_i_1_1_data_profile_hasher.html", null ],
    [ "Mvx2API::DataProfileIterator", "class_mvx2_a_p_i_1_1_data_profile_iterator.html", null ],
    [ "MVX::ErrorHolder", "class_m_v_x_1_1_error_holder.html", null ],
    [ "MVX::FilterClassInfo", "class_m_v_x_1_1_filter_class_info.html", null ],
    [ "MVX::FilterFactoryIterator", "class_m_v_x_1_1_filter_factory_iterator.html", null ],
    [ "Mvx2API::FilterList", "class_mvx2_a_p_i_1_1_filter_list.html", null ],
    [ "Mvx2API::FilterParameterNameIterator", "class_mvx2_a_p_i_1_1_filter_parameter_name_iterator.html", null ],
    [ "MVX::GenericSharedDataLayerPtr< TDataLayerClass >", "class_m_v_x_1_1_generic_shared_data_layer_ptr.html", null ],
    [ "MVX::GenericSharedFilterPtr< TFilterClass >", "class_m_v_x_1_1_generic_shared_filter_ptr.html", null ],
    [ "MVX::IMVXLoggerInstanceListener", "class_m_v_x_1_1_i_m_v_x_logger_instance_listener.html", null ],
    [ "Mvx2API::InputEvent", "struct_mvx2_a_p_i_1_1_input_event.html", [
      [ "Mvx2API::KeyDownEvent", "struct_mvx2_a_p_i_1_1_key_down_event.html", null ],
      [ "Mvx2API::KeyUpEvent", "struct_mvx2_a_p_i_1_1_key_up_event.html", null ],
      [ "Mvx2API::MouseDoubleClickEvent", "struct_mvx2_a_p_i_1_1_mouse_double_click_event.html", null ],
      [ "Mvx2API::MouseDownEvent", "struct_mvx2_a_p_i_1_1_mouse_down_event.html", null ],
      [ "Mvx2API::MouseMoveEvent", "struct_mvx2_a_p_i_1_1_mouse_move_event.html", null ],
      [ "Mvx2API::MouseUpEvent", "struct_mvx2_a_p_i_1_1_mouse_up_event.html", null ],
      [ "Mvx2API::MouseWheelEvent", "struct_mvx2_a_p_i_1_1_mouse_wheel_event.html", null ]
    ] ],
    [ "NonAssignable", null, [
      [ "Mvx2API::Frame", "class_mvx2_a_p_i_1_1_frame.html", null ],
      [ "Mvx2API::FrameListener", "class_mvx2_a_p_i_1_1_frame_listener.html", null ],
      [ "Mvx2API::Graph", "class_mvx2_a_p_i_1_1_graph.html", null ],
      [ "Mvx2API::GraphBuilder", "class_mvx2_a_p_i_1_1_graph_builder.html", [
        [ "Mvx2API::ManualGraphBuilder", "class_mvx2_a_p_i_1_1_manual_graph_builder.html", null ]
      ] ],
      [ "Mvx2API::GraphNode", "class_mvx2_a_p_i_1_1_graph_node.html", [
        [ "Mvx2API::AutoCompressorGraphNode", "class_mvx2_a_p_i_1_1_auto_compressor_graph_node.html", null ],
        [ "Mvx2API::AutoDecompressorGraphNode", "class_mvx2_a_p_i_1_1_auto_decompressor_graph_node.html", null ],
        [ "Mvx2API::BlockGraphNode", "class_mvx2_a_p_i_1_1_block_graph_node.html", [
          [ "Mvx2API::BlockFPSGraphNode", "class_mvx2_a_p_i_1_1_block_f_p_s_graph_node.html", null ],
          [ "Mvx2API::BlockManualGraphNode", "class_mvx2_a_p_i_1_1_block_manual_graph_node.html", null ]
        ] ],
        [ "Mvx2API::InjectMemoryDataGraphNode", "class_mvx2_a_p_i_1_1_inject_memory_data_graph_node.html", null ],
        [ "Mvx2API::ManualLiveFrameSourceGraphNode", "class_mvx2_a_p_i_1_1_manual_live_frame_source_graph_node.html", null ],
        [ "Mvx2API::ManualOfflineFrameSourceGraphNode", "class_mvx2_a_p_i_1_1_manual_offline_frame_source_graph_node.html", null ],
        [ "Mvx2API::SingleFilterGraphNode", "class_mvx2_a_p_i_1_1_single_filter_graph_node.html", [
          [ "Mvx2API::AsyncFrameAccessGraphNode", "class_mvx2_a_p_i_1_1_async_frame_access_graph_node.html", null ],
          [ "Mvx2API::Experimental::RendererGraphNode", "class_mvx2_a_p_i_1_1_experimental_1_1_renderer_graph_node.html", null ],
          [ "Mvx2API::FrameAccessGraphNode", "class_mvx2_a_p_i_1_1_frame_access_graph_node.html", null ],
          [ "Mvx2API::InjectFileDataGraphNode", "class_mvx2_a_p_i_1_1_inject_file_data_graph_node.html", null ]
        ] ]
      ] ],
      [ "Mvx2API::GraphRunner", "class_mvx2_a_p_i_1_1_graph_runner.html", [
        [ "Mvx2API::AutoSequentialGraphRunner", "class_mvx2_a_p_i_1_1_auto_sequential_graph_runner.html", null ],
        [ "Mvx2API::ManualSequentialGraphRunner", "class_mvx2_a_p_i_1_1_manual_sequential_graph_runner.html", null ],
        [ "Mvx2API::RandomAccessGraphRunner", "class_mvx2_a_p_i_1_1_random_access_graph_runner.html", null ]
      ] ],
      [ "Mvx2API::IParameterValueChangedListener", "class_mvx2_a_p_i_1_1_i_parameter_value_changed_listener.html", null ],
      [ "Mvx2API::MeshData", "class_mvx2_a_p_i_1_1_mesh_data.html", null ],
      [ "Mvx2API::MeshSplitter", "class_mvx2_a_p_i_1_1_mesh_splitter.html", null ],
      [ "Mvx2API::SourceInfo", "class_mvx2_a_p_i_1_1_source_info.html", null ]
    ] ],
    [ "MVX::PluginInfo", "struct_m_v_x_1_1_plugin_info.html", null ],
    [ "Mvx2API::SharedAtomPtr", "class_mvx2_a_p_i_1_1_shared_atom_ptr.html", null ],
    [ "MVX::SharedDataLayerPtr", "class_m_v_x_1_1_shared_data_layer_ptr.html", null ],
    [ "MVX::SharedFilterPtr", "class_m_v_x_1_1_shared_filter_ptr.html", null ],
    [ "Mvx2API::SharedFilterPtr", "class_mvx2_a_p_i_1_1_shared_filter_ptr.html", null ],
    [ "MVX::SharedGraphPtr", "class_m_v_x_1_1_shared_graph_ptr.html", null ],
    [ "Mvx2API::Vec2Data", "struct_mvx2_a_p_i_1_1_vec2_data.html", null ],
    [ "Mvx2API::Vec3Data", "struct_mvx2_a_p_i_1_1_vec3_data.html", null ]
];