var _mvx_version_8h =
[
    [ "MVX_VERSION_MAJOR", "_mvx_version_8h.html#a6aa129f88575146fae107c71f8ebe3fe", null ],
    [ "MVX_VERSION_MINOR", "_mvx_version_8h.html#a4b3c2bf3aba350b55f0645df488bdc36", null ],
    [ "MVX_VERSION_PATCH", "_mvx_version_8h.html#a20150d52d1a679ccf97230dde2303db5", null ],
    [ "MVX_COMPILE_VERSION", "_mvx_version_8h.html#ad8186218312c26d7a6e8fa9b6d60f9b3", null ],
    [ "MVX_RUNTIME_VERSION", "_mvx_version_8h.html#aeab17468210696b55cfeb4da9af66f51", null ]
];