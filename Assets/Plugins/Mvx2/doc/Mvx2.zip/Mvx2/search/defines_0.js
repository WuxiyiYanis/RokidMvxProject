var searchData=
[
  ['datalayer_5fdecl_867',['DATALAYER_DECL',['../_data_layer_definition_8h.html#a17f13f4f8796456300a793c446ff433f',1,'DataLayerDefinition.h']]],
  ['datalayer_5fdecl_5fexport_868',['DATALAYER_DECL_EXPORT',['../_data_layer_definition_8h.html#a2ad532ca031934a31d55c9ca95a51b01',1,'DataLayerDefinition.h']]],
  ['declare_5fpurpose_5fguid_869',['DECLARE_PURPOSE_GUID',['../_m_v_x_purpose_guids_8h.html#af8506a74b98b146f7d9a3bd152723837',1,'MVXPurposeGuids.h']]]
];
