var searchData=
[
  ['a_769',['a',['../struct_mvx2_a_p_i_1_1_col_r_g_b_a_data.html#ad7b99e1fde2ab41be124d9f4c7285f0f',1,'Mvx2API::ColRGBAData']]]
];
