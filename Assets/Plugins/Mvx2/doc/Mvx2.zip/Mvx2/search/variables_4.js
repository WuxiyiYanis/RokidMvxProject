var searchData=
[
  ['mvx_5fcompile_5fversion_776',['MVX_COMPILE_VERSION',['../_mvx_version_8h.html#ad8186218312c26d7a6e8fa9b6d60f9b3',1,'MVX']]],
  ['mvx_5fruntime_5fversion_777',['MVX_RUNTIME_VERSION',['../_mvx_version_8h.html#aeab17468210696b55cfeb4da9af66f51',1,'MVX']]],
  ['mvxversion_778',['mvxVersion',['../struct_m_v_x_1_1_plugin_info.html#af79425b124e2000fefde5de85ec6a7b0',1,'MVX::PluginInfo']]],
  ['mvxversionstr_779',['mvxVersionStr',['../struct_m_v_x_1_1_plugin_info.html#a5fa440ef7f6395848534fadc8fbec407',1,'MVX::PluginInfo']]]
];
