var searchData=
[
  ['plugininfo_469',['PluginInfo',['../struct_m_v_x_1_1_plugin_info.html',1,'MVX']]]
];
