var class_mvx2_a_p_i_1_1_plugins_loader =
[
    [ "LoadPlugin", "class_mvx2_a_p_i_1_1_plugins_loader.html#a3ab804d2ad0f0a92b49792accd868882", null ],
    [ "LoadPluginsInFolder", "class_mvx2_a_p_i_1_1_plugins_loader.html#a85305df51f47556b9381dbfad1b0e1de", null ]
];