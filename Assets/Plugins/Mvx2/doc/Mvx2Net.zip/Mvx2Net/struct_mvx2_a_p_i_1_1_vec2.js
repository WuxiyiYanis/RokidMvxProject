var struct_mvx2_a_p_i_1_1_vec2 =
[
    [ "x", "struct_mvx2_a_p_i_1_1_vec2.html#a2d0f9a9ad90386742bcaadbc07466e06", null ],
    [ "y", "struct_mvx2_a_p_i_1_1_vec2.html#ad0d011887defbdae176c77694968b9b6", null ]
];