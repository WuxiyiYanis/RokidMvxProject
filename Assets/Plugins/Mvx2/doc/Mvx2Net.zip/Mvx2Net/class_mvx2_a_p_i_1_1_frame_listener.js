var class_mvx2_a_p_i_1_1_frame_listener =
[
    [ "FrameListener", "class_mvx2_a_p_i_1_1_frame_listener.html#a17abfce1f3f7962fcc61ba0a254a70b6", null ],
    [ "DestroyNativeObject", "class_mvx2_a_p_i_1_1_frame_listener.html#ab070e5df885855bd45744ab52ec85cb2", null ],
    [ "OnFrameProcessed", "class_mvx2_a_p_i_1_1_frame_listener.html#aeea43eefff89b8ab231480090189b6e1", null ],
    [ "nativeFrameListenerObject", "class_mvx2_a_p_i_1_1_frame_listener.html#a3590a5c482da9dc3358b1e32c3af19ad", null ]
];