var searchData=
[
  ['etc2_5ftexture_5fdata_5flayer_56',['ETC2_TEXTURE_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#add88650747487b06545c66cbc175f5dc',1,'Mvx2API::BasicDataLayersGuids']]]
];
