var searchData=
[
  ['camera_5fparams_5fdata_5flayer_477',['CAMERA_PARAMS_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#a59912deb43c314ada53dee73c044dad5',1,'Mvx2API::BasicDataLayersGuids']]],
  ['compressedtypeguid_478',['compressedTypeGuid',['../class_mvx2_a_p_i_1_1_data_profile.html#ad5a2cfafba152ab136a2f9d1a8b5b1fd',1,'Mvx2API::DataProfile']]]
];
