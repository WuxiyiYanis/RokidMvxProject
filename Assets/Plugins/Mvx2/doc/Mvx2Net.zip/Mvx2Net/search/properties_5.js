var searchData=
[
  ['ir_5ftexture_5fdata_5flayer_483',['IR_TEXTURE_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#a0629547fee4587c04433bfd6b2f4b316',1,'Mvx2API::BasicDataLayersGuids']]]
];
