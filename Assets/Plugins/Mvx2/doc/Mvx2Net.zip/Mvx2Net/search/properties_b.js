var searchData=
[
  ['transform_5fdata_5flayer_498',['TRANSFORM_DATA_LAYER',['../class_mvx2_a_p_i_1_1_basic_data_layers_guids.html#aa0b9dd5e2c93caa371d14fcdc5a791f3',1,'Mvx2API::BasicDataLayersGuids']]],
  ['typeguid_499',['typeGuid',['../class_mvx2_a_p_i_1_1_data_profile.html#a10a826b578ac69e63a78370839e376b3',1,'Mvx2API::DataProfile']]]
];
