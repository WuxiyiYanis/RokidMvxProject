var struct_mvx2_a_p_i_1_1_col =
[
    [ "a", "struct_mvx2_a_p_i_1_1_col.html#a98e7ef356d76e6c1277335d5b33a82cb", null ],
    [ "b", "struct_mvx2_a_p_i_1_1_col.html#a0fc7d29de51085f82dc591669b51d099", null ],
    [ "g", "struct_mvx2_a_p_i_1_1_col.html#a8a5ef4c54f5efe0adc3a5e250f580b98", null ],
    [ "r", "struct_mvx2_a_p_i_1_1_col.html#a63cc4bbceddec675ede2659d28c8831e", null ]
];