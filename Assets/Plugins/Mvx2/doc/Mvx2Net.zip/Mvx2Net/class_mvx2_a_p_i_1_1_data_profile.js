var class_mvx2_a_p_i_1_1_data_profile =
[
    [ "DataProfile", "class_mvx2_a_p_i_1_1_data_profile.html#a3b64bf39547b2b613b912066fd2d45ed", null ],
    [ "DestroyNativeObject", "class_mvx2_a_p_i_1_1_data_profile.html#a35258a4841e9408adf2d5bc8d2d5bf92", null ],
    [ "compressedTypeGuid", "class_mvx2_a_p_i_1_1_data_profile.html#ad5a2cfafba152ab136a2f9d1a8b5b1fd", null ],
    [ "nativeDataProfileObject", "class_mvx2_a_p_i_1_1_data_profile.html#aa37160db7f55e807d515db646bec3e62", null ],
    [ "purposeGuid", "class_mvx2_a_p_i_1_1_data_profile.html#ad8a3bda6a7bdaee43d5b8c489047890f", null ],
    [ "typeGuid", "class_mvx2_a_p_i_1_1_data_profile.html#a10a826b578ac69e63a78370839e376b3", null ]
];