var class_mvx2_a_p_i_1_1_block_graph_node =
[
    [ "FullBehaviour", "class_mvx2_a_p_i_1_1_block_graph_node.html#af56e4560a78f96cbe9fcc585d0bb100e", [
      [ "FB_DROP_FRAMES", "class_mvx2_a_p_i_1_1_block_graph_node.html#af56e4560a78f96cbe9fcc585d0bb100ead20c9800480e9120387a7147d15232f4", null ],
      [ "FB_BLOCK_FRAMES", "class_mvx2_a_p_i_1_1_block_graph_node.html#af56e4560a78f96cbe9fcc585d0bb100eaa10299ee1abea396f6bdaf13a908ad12", null ]
    ] ],
    [ "BlockGraphNode", "class_mvx2_a_p_i_1_1_block_graph_node.html#a68d92f9cc1a512bb878bc5dbc92671e0", null ],
    [ "GetDroppedFramesCount", "class_mvx2_a_p_i_1_1_block_graph_node.html#a68f7c242f1318edc61daab7514bc41a1", null ],
    [ "ResetDroppedFramesCounter", "class_mvx2_a_p_i_1_1_block_graph_node.html#aa9287686fa45e34bac476f29ea68727c", null ],
    [ "SetFullBehaviour", "class_mvx2_a_p_i_1_1_block_graph_node.html#a0be3ad151ed8193da2d3986ecd1a6b49", null ]
];