var class_mvx2_a_p_i_1_1_frame_access_graph_node =
[
    [ "FrameAccessGraphNode", "class_mvx2_a_p_i_1_1_frame_access_graph_node.html#a2188076b530b7a20adeca69664cfde90", null ],
    [ "GetRecentProcessedFrame", "class_mvx2_a_p_i_1_1_frame_access_graph_node.html#a4894dd12ad1e59689d923a1e33707589", null ]
];